if (window['google'] != undefined && window['google']['loader'] != undefined) {
if (!window['google']['visualization']) {
window['google']['visualization'] = {};
google.visualization.Version = '1.0';
google.visualization.JSHash = '';
google.visualization.LoadArgs = '';
}
google.loader.writeLoadTag("css", google.loader.ServiceBase + "/../ui+pt_BR.css", false);
google.loader.writeLoadTag("script", google.loader.ServiceBase + "/../format+pt_BR,default+pt_BR,ui+pt_BR,corechart+pt_BR.I.js", false);
}